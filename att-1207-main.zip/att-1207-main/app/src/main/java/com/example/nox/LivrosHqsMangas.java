package com.example.nox;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class LivrosHqsMangas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_livros_hqs_mangas);
    }
}
