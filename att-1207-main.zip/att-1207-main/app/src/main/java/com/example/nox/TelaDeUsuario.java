package com.example.nox;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TelaDeUsuario extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_de_usuario);
    }
}
